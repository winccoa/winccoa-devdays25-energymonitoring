
let os = '';
if (navigator.appVersion.indexOf('Win') !== -1) os = 'windows';
//if (navigator.appVersion.indexOf('Mac') != -1) os = 'MacOS';
if (navigator.appVersion.indexOf('X11') !== -1) os = 'linux';
if (navigator.appVersion.indexOf('Linux') !== -1) os = 'linux';

const populateTable = (data) => {
  const grouped = {};
  if (data.hasOwnProperty("files"))
  {
    data.files.forEach(entry => {
      if (!(entry.package in grouped)) {
        grouped[entry.package] = [];
      }
      grouped[entry.package].push({
        platform: entry.platform,
        file: entry.file,
      })
    });
  }

  const container = document.getElementById("container_content");

  if (Object.entries(grouped).length > 0)
  {
    Object.entries(grouped).forEach(([key, entries]) => {

      //headline
      const headline = document.createElement("h1");
      headline.innerHTML = key+" Downloads";
      container.appendChild(headline);

      //div
      const div = document.createElement("div");
      div.classList="download-container__download-section__single";

      //buttons
      entries.forEach(entry => {
        const button = document.createElement("button");
        button.classList="button download";
        button.setAttribute("data-file", entry.file);
        button.innerHTML=entry.platform;
        div.appendChild(button);
      });
      container.appendChild(div);
    });
  }
  else
  {
    const message = document.createElement("h3");
    message.innerHTML = "Desktop UI packages have not been found";
    const details = document.createElement("p")
    details.innerHTML = "Proceed to the winccoa portal to download the latest Desktop UI package";
    container.appendChild(message);
    container.appendChild(details);

    const button = document.createElement("button");
    button.classList="button download";
    button.setAttribute("data-file", data["download-link"]);
    button.innerHTML="www.winccoa.com";
    container.appendChild(button);
  }

  $(".download").click((e) => {
    download(e.currentTarget.getAttribute("data-file"));
  });
}
download = (file) =>{
  document.location.href=file;
}
readPackagesFromBackend = () => {
  $.get( "_info?clSetup="+os, function( response ) {
    populateTable(JSON.parse(response));
  });
}
$(document).ready(function () {
  readPackagesFromBackend();

});
